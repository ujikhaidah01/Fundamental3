package com.example.buah.preference

import android.content.Context
import com.example.buah.recyclerView.Reminder

class ReminderPreference(context: Context) {
    companion object{
        const val PREFS_NAMA = "reminder_pref"
        private const val REMINDER = "isRemind"
    }

    private  val preference = context.getSharedPreferences(PREFS_NAMA, Context.MODE_PRIVATE)

    fun setReminder (value : Reminder){
        val editor = preference.edit()
        editor.putBoolean(REMINDER, value.isReminded)
        editor.apply()
    }

    fun getReminder(): Reminder{
        val model = Reminder()
        model.isReminded = preference.getBoolean(REMINDER, false)
        return model
    }
}