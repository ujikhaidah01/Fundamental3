package com.example.buah.ui.favorite

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.buah.R
import com.example.buah.db.AppDB
import com.example.buah.db.FavoriteDao
import com.example.buah.recyclerView.UserDataModel
import com.example.buah.recyclerView.UserDetail
import kotlinx.android.synthetic.main.item_fav.view.*
import kotlinx.coroutines.launch

class FavoriteAdapter(private val userList: List<UserDataModel>): RecyclerView.Adapter<FavoriteAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_fav, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavoriteAdapter.ViewHolder, position: Int) {
        val userFav = userList[position]
        holder.bind(userFav)
        with(holder.itemView) {
            Glide.with(context)
                .load(userFav.logo)
                .into(img_fav_foto)

            tv_fav_nama.text = userFav.name
            tv_fav_username.text = userFav.login
            tv_fav_lokasi.text = userFav.location
            btn_fav_delete.setOnClickListener {
                val favoriteDao: FavoriteDao = AppDB.getDatabase(context).favoriteDAO()
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                    favoriteDao.hapusDariFav(userFav.id!!)
                }
            }

        }
    }

    override fun getItemCount() = userList.size

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(detailuser: UserDataModel) {
            val userFav = detailuser

            with(itemView) {
                Glide.with(context)
                    .load(detailuser.logo)
                    .into(img_fav_foto)
                tv_fav_nama.text = userFav.name
                tv_fav_username.text = userFav.login
                tv_fav_lokasi.text = userFav.location

                itemView.setOnClickListener {
                    Intent(context, UserDetail::class.java).apply {
                        putExtra(UserDetail.Usernamenya, detailuser.login)
                    }.run {
                        context.startActivity(this)
                    }
                }
            }
        }
    }
}