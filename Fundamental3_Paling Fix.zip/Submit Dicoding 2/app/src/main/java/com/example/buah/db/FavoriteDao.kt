package com.example.buah.db

import android.database.Cursor
import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.buah.recyclerView.UserDataModel


@Dao
interface FavoriteDao {
    @Insert
    suspend fun addToFavorite(favoriteUserModel: UserDataModel)

    @Query("SELECT * FROM favorite_user")
    fun getFavoriteUser(): LiveData<List<UserDataModel>>

    @Query("SELECT * FROM favorite_user")
    fun getOneFavoriteUser() : List<UserDataModel>

    @Query("SELECT count(*) FROM favorite_user WHERE favorite_user.id = :id")
    suspend fun checkUser(id:Int): Int

    @Query("DELETE FROM favorite_user WHERE favorite_user.id = :id")
    suspend fun hapusDariFav(id: Int): Int

    @Query("SELECT * FROM favorite_user")
    fun findAll(): Cursor
}