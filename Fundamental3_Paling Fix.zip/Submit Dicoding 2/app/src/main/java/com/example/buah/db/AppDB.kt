package com.example.buah.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room.databaseBuilder
import androidx.room.RoomDatabase
import com.example.buah.recyclerView.UserDataModel

@Database(
        entities = [
            UserDataModel::class
        ],
        version = 1
)

abstract class AppDB: RoomDatabase() {

    abstract fun favoriteDAO(): FavoriteDao

    companion object {
        @Volatile
        private var INSTANCE: AppDB? = null

        fun getDatabase(context: Context): AppDB {
            val tempInstance = INSTANCE
            if (tempInstance != null) {
                return tempInstance
            }
            synchronized(this) {
                val instance = databaseBuilder(context.applicationContext, AppDB::class.java, "favorite.db")
                        .fallbackToDestructiveMigration()
                        .build()
                INSTANCE = instance
                return instance
            }
        }
    }
}