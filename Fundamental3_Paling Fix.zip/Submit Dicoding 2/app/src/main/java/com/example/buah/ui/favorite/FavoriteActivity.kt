package com.example.buah.ui.favorite

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import com.example.buah.R
import com.example.buah.db.AppDB
import com.example.buah.db.FavoriteDao
import com.example.buah.recyclerView.UserDataModel
import kotlinx.android.synthetic.main.activity_favorite.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class FavoriteActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorite)

//        val ischeck = false
//
//        CoroutineScope(Dispatchers.IO).launch {
//            val count = viewModel()
//        }

        val favoriteDao: FavoriteDao = AppDB.getDatabase(application).favoriteDAO()
        val favoriteListDB: LiveData<List<UserDataModel>>?
        favoriteListDB = favoriteDao.getFavoriteUser()
        Log.d("ROOM_GET", favoriteListDB.value.toString())


        favoriteListDB.observe(this@FavoriteActivity, Observer {
            if(it.isNotEmpty()) {
                val listFavAdapter = FavoriteAdapter(it)
                recycler_view_fav.adapter = listFavAdapter

                Log.d("ROOM_GET", "Ada Data")
                Log.d("ROOM_GET", it[0].name.toString())
                Log.d("ROOM_GET", it[0].login.toString())
                Log.d("ROOM_GET", it.toString())
            }
            else {
                Log.d("ROOM_GET", "Tidak ada data pada Database")
            }
        })
    }
}