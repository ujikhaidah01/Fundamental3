package com.example.buah.setting

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.buah.databinding.ActivitySettingBinding
import com.example.buah.preference.ReminderPreference
import com.example.buah.receiver.Alarm
import com.example.buah.recyclerView.Reminder

class SettingActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingBinding
    private lateinit var reminder: Reminder
    private lateinit var alarm: Alarm

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val reminderPreference = ReminderPreference ( this)
        if (reminderPreference.getReminder().isReminded){
            binding.switch1.isChecked = true
        }else{
            binding.switch1.isChecked = false
        }

        alarm = Alarm()

        binding.switch1.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked){
                saveReminder(true)
                alarm.setRepeatingAlarm(this, "Alarm Aktif", "09:00", " Silakan Kembali Ke Github")
            }else {
                saveReminder(false)
                alarm.cancelAlarm(this)
            }
        }
    }

    private fun saveReminder(state : Boolean){
        val reminderPreference = ReminderPreference(this)
        reminder = Reminder()

        reminder.isReminded = state
        reminderPreference.setReminder(reminder)
    }
}