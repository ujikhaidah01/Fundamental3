package com.example.buah.recyclerView

data class Reminder(
    var isReminded: Boolean = false
)
