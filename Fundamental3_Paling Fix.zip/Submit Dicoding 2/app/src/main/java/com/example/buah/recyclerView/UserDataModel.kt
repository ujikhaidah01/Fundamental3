package com.example.buah.recyclerView

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "favorite_user")
data class UserDataModel (
        @PrimaryKey(autoGenerate = true) var id:Int? = null,
        var repository: Int? = 0,
        var followers: Int? = 0,
        var following: Int? = 0,
        var logo: String? = null,
        var username: String? = null,
        var name: String? = null,
        var login: String? = null,
        var location: String? = null
)  : Parcelable