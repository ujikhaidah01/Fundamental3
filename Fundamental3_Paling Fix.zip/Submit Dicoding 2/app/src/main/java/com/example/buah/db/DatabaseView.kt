package com.example.buah.db

import android.app.Application
import com.facebook.stetho.Stetho

class DatabaseView : Application() {
    override fun onCreate() {
        super.onCreate()
        Stetho.initializeWithDefaults(this) }
}