package com.example.buah.recyclerView

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.*
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.buah.R
import com.example.buah.adapter.DetailAdapter
import com.example.buah.adapter.PenghubungAdapter
import com.example.buah.db.AppDB
import com.example.buah.db.FavoriteDao
import com.example.buah.fragment.FragmentDetail
import kotlinx.android.synthetic.main.activity_user_detail.*
import kotlinx.android.synthetic.main.tabnya.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class UserDetail : AppCompatActivity() {

    private lateinit var fragmentDetail: FragmentDetail
    private lateinit var detailAdapter: DetailAdapter
    private lateinit var dataDetail: List<UserDataModel>
    private var listUsernameDB = mutableListOf<String?>();

    companion object {
        const val Usernamenya = "extra_username"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_detail)

        detailAdapter = DetailAdapter()

        val username = intent.getStringExtra(Usernamenya)

        fragmentDetail = ViewModelProvider(this).get(FragmentDetail::class.java)

        fragmentDetail.setUserDetail(username!!)
        fragmentDetail.getDetail().observe(this, Observer { detailItemUser ->
            if (detailItemUser != null) {
                detailAdapter.setData(detailItemUser)
                dataDetail = detailItemUser
            }
        })
        recycler()
        toolbar()
        penghubungAdapterr()
    }

    private fun recycler() {
        detaillayout.layoutManager = LinearLayoutManager(this)
        detaillayout.adapter = detailAdapter
    }

    private fun toolbar() {
        val actionBar = supportActionBar
        actionBar!!.title = resources.getString(R.string.title_detail)
        actionBar.setDisplayHomeAsUpEnabled(true)
    }

    private fun penghubungAdapterr() {
        val penghubungAdapter = PenghubungAdapter(this, supportFragmentManager)
        penghubungview.adapter = penghubungAdapter
        tabs.setupWithViewPager(penghubungview)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menudetail, menu)
        return super.onCreateOptionsMenu(menu)
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId){
            R.id.like -> {
                CoroutineScope(Dispatchers.IO).launch {
                    val favoriteDao: FavoriteDao = AppDB.getDatabase(application).favoriteDAO()
                    favoriteDao.getOneFavoriteUser().listIterator().forEach{
                        listUsernameDB.add(it.login)
                    }
                    if (listUsernameDB.contains(dataDetail[0].login)){
                        this@UserDetail.runOnUiThread {
                            Toast.makeText(this@UserDetail, " data sudah tersimpan !", Toast.LENGTH_SHORT).show()
                        }
                    }else{
                        favoriteDao.addToFavorite(dataDetail[0])
                        this@UserDetail.runOnUiThread {
                            Toast.makeText(this@UserDetail, " Berhasil ditambahkan !", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }

            R.id.Pengaturanbahasa ->{
                Toast.makeText(this,"Pengaturan Bahasa", Toast.LENGTH_SHORT).show()
                val intent = Intent(Settings.ACTION_LOCALE_SETTINGS)
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }

}



