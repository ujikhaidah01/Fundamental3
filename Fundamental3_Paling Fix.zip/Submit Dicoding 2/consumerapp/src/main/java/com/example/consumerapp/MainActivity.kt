package com.example.consumerapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.consumerapp.content_resolver.DatabaseContract.FavoriteUserColom.Companion.CONTENT_URI
import com.example.consumerapp.content_resolver.MappingHelper
import kotlinx.android.synthetic.main.activity_main_cons.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_cons)

        CoroutineScope(Dispatchers.IO).launch {
            val cursor = contentResolver.query(CONTENT_URI, null, null, null, null)
            val listItem = MappingHelper.mapCursorToArrayList(cursor)
            Log.d("CONTENT_PROVIDER", "Value = $listItem")
            val listFavAdapter = FavoriteAdapter(listItem)
            recycler_view_fav_cons.adapter = listFavAdapter
        }
    }
}