package com.example.consumerapp.content_resolver

import android.database.Cursor
import com.example.consumerapp.model.UserDataModel

object MappingHelper {
    fun mapCursorToArrayList(cursor: Cursor?):ArrayList<UserDataModel>{
        val list = ArrayList<UserDataModel>()
        if (cursor != null){
            while (cursor.moveToNext()){
                val id =  cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContract.FavoriteUserColom.ID))
                val username = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.FavoriteUserColom.USERNAME))
                val logo = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.FavoriteUserColom.LOGO))
                list.add(
                        UserDataModel(
                                id,
                                logo,
                                username
                        )
                )
            }
        }
        return list
    }
}