package com.example.consumerapp.model

import androidx.room.Entity
import androidx.room.PrimaryKey


data class UserDataModel(
        var id:Int? = null,
        var logo: String? = null,
        var name: String? = null,
        var login: String? = null,
        var location: String? = null
)