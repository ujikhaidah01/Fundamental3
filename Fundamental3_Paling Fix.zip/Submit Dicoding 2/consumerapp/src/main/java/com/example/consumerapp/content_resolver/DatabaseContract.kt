package com.example.consumerapp.content_resolver

import android.net.Uri
import android.provider.BaseColumns

object DatabaseContract {
    const val AUTHORITY = "com.example.buah"
    const val  SCHEME = "content"

    internal class FavoriteUserColom : BaseColumns {
        companion object{
            const val TABLE_NAMA = "favorite_user"
            const val ID = "id"
            const val LOGO = "logo"
            const val USERNAME = "login"

            val CONTENT_URI: Uri = Uri.Builder().scheme(SCHEME)
                    .authority(AUTHORITY)
                    .appendPath(TABLE_NAMA)
                    .build()
        }
    }
}